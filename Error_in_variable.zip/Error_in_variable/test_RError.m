%% ***************************************************************
%%  test_RError
%% ***************************************************************
%%
%% Copyright by Shaohua Pan, 2017.12.15
%% ****************************************************************
%% A0 for additive;             hsigma = 0.75
%% A1-A2 for additive;          hsigma = 1.0; lsigma = 0.5
%% M1-M2 for multiplicative;    hsigma = 0.8; lsigma = 0.5
%% M4-M5 for missing            hsigma = 0.5; lsigma = 0.3
%%

clear;

addpath(genpath(pwd))


%% **************************************************************

randstate = 1;
randn('state',double(randstate));
rand('state',double(randstate));

tiny = 1e-8;

small_tol = 1e-5;

%% ****************** to set the parameter ***********************

example_type = 'A0';

p = 250;

sigma = 0.75;

ysigma = 0.5;

pars.prob = sigma;   % used for missing data

%% ************* to generate the true betatstar ******************

k = round(0.5*sqrt(p));    % k-sparse

temp_supp = randperm(p);

supp_betastar = temp_supp(1:k);

betastar = zeros(p,1);

betastar(supp_betastar) = randn(k,1);

sign_supp_betastar = sign(betastar(supp_betastar));

betastarnorm = norm(betastar);


%% ************ parameters for ADMM_tau and GEP-MSCRA ***************

OPTIONS_ADMM.tol = 1.0e-4;

OPTIONS_ADMM.printyes = 0;

OPTIONS_ADMM.maxiter = 2000;

OPTIONS_MSCRA.printyes = 0;

OPTIONS_MSCRA.tol = 1.0e-1;

pars.dim = p;

%% **************** make 5-fold corrected CV *********************

fprintf('\n *********************** The CV stage ************************');

pars.sn = round(5*k*log(p));

alpha = [0.06   0.08    0.11    0.14    0.16    0.18    0.20    0.22    0.24    0.26    0.29    0.32]';


[~,~,Z_CV,y_CV] = gen_example(betastar,pars,sigma,ysigma,example_type,randstate);


[alpha_Fro,alpha_Inf] = CV_alpha(betastar,Z_CV,y_CV,pars,OPTIONS_MSCRA,OPTIONS_ADMM,alpha,sigma,example_type);

%% ***************** Initialization part ************************

sn_factor = [4   4.2   4.4    4.6    4.8    5   5.2   5.4    5.6    5.8   6.0]';

ns = length(sn_factor);

ns_list = zeros(ns,1);     % used for plotting the figure

aveFnorm_Err = size(ns,1);  aveFnorm_nz = size(ns,1);

aveFnorm_Indx = size(ns,1);  aveFnorm_time = size(ns,1);

aveInf_Err = size(ns,1);   aveInf_nz = size(ns,1);

aveInf_Indx = size(ns,1);  aveInf_time = size(ns,1);

aveLoh_Err = size(ns,1);   aveLoh_nz = size(ns,1);

aveLoh_Indx = size(ns,1);  aveLoh_time = size(ns,1);

%**********************************************************************

ntest = 100;    % the number of test problems

Fnorm_Err = size(ns,ntest);  Fnorm_nz = size(ns,ntest);

Fnorm_Indx = size(ns,ntest);  Fnorm_time = size(ns,ntest);

Inf_Err = size(ns,ntest);  Inf_nz = size(ns,ntest);

Inf_Indx = size(ns,ntest);  Inf_time = size(ns,ntest);

Loh_Err = size(ns,ntest);  Loh_nz = size(ns,ntest);

Loh_Indx = size(ns,ntest);  Loh_time = size(ns,ntest);

%% *******************  main loop  *******************************
for i = 1:ns;
    
    fprintf('\n ************ the ith sn_factor: i = %d',i);
    
    n = round(sn_factor(i)*k*log(p));
    
    ns_list(i) = n;
    
    pars.sn = n;   %% do not forget this !!!
    
    for t = 1:ntest
        
        randstate = t;
        randn('state',double(randstate));
        rand('state',double(randstate));
        
        %% ************* generate noisy data and parameters *************
        
        [Q,bb] = gen_example(betastar,pars,sigma,ysigma,example_type,randstate);
        
        
        %% ******************* Fnorm *************************************
        
        x_start = zeros(p,1);
        
        tstart = clock;
        
        [Z_Fro,yy] = SRproj_PSD(Q,small_tol,bb,n);
        
        OPTIONS_MSCRA.normb = norm(yy);
        
        OPTIONS_MSCRA.maxiter = 4;
        
        lambda = max(0.01,(alpha_Fro/n)*max(abs(Z_Fro'*yy)));
        
        [xopt_fro,nznorm_fro] = MSCRA_Unconstr(x_start,Z_Fro,yy,pars,OPTIONS_MSCRA,lambda,betastar);
        
        Fnorm_time(i,t) = etime(clock,tstart);
        
        sign_supp_xoptfro = sign(xopt_fro(supp_betastar));
        
        Fnorm_nz(i,t) = nznorm_fro;
        
        Fnorm_Err(i,t) = norm(xopt_fro-betastar)/betastarnorm;
        
        Fnorm_Indx(i,t)= length(find(abs(sign_supp_xoptfro-sign_supp_betastar)<=tiny));
        
        %% ********************* Inf_norm *******************************
        
        pen_factor = 1;
        
        x_start = zeros(p,1);
        
        tstart = clock;
        
        [Z_Inf,yy] = Zou_ADMM_tau(Q,OPTIONS_ADMM,pen_factor,bb,n);
        
        OPTIONS_MSCRA.normb = norm(yy);
        
        lambda = max(0.01,(alpha_Inf/n)*max(abs(Z_Inf'*yy)));
        
        OPTIONS_MSCRA.maxiter = 1;
        
        [xopt_inf,nznorm_inf] = MSCRA_Unconstr(x_start,Z_Inf,yy,pars,OPTIONS_MSCRA,lambda,betastar);
        
        Inf_time(i,t) = etime(clock,tstart);
        
        sign_supp_xoptinf = sign(xopt_inf(supp_betastar));
        
        Inf_Err(i,t)= norm(xopt_inf-betastar)/betastarnorm;
        
        Inf_nz(i,t) = nznorm_inf;
        
        Inf_Indx(i,t) = length(find(abs(sign_supp_xoptinf -sign_supp_betastar)<=tiny));
        %
        
        %% ********************* Loh's method ***************************
        
        R1 = sum(abs(betastar));
        
        MAXITS = 5000;       % maximum number of iterations
        
        stepsize = .05;      % stepsize
        
        tstart = clock;
        
        [betanew,its1] = doProjGrad(Q,bb,MAXITS,stepsize,R1);
        
        Loh_time(i,t)= etime(clock,tstart);
        
        sign_supp_betanew = sign(betanew(supp_betastar));
        
        Loh_Err(i,t) = norm(betanew-betastar)/betastarnorm;
        
        Loh_nz(i,t) = length(find(abs(betanew)>1.0e-8));
        
        Loh_Indx(i,t) = length(find(abs(sign_supp_betanew-sign_supp_betastar)<=tiny));
        
        R = sum(abs(betastar));
        
        lambda = 0.05*sqrt(log(p)/n);
        
        MAXITS = 3000;       % maximum number of iterations
        
        stepsize = .05;      % stepsize
        
        tstart = clock;
        
        [betanew, its1] = doCompGrad(Q,bb,MAXITS,stepsize,R,lambda);
        
        Loh_time(i,t)= etime(clock,tstart);
        
        sign_supp_betanew = sign(betanew(supp_betastar));
        
        Loh_Err(i,t) = norm(betanew-betastar)/betastarnorm
        
        Loh_nz(i,t)= length(find(abs(betanew)>1.0e-8));
        
        Loh_Indx(i,t) = length(find(abs(sign_supp_betanew-sign_supp_betastar)<=tiny));
        
    end
    
    aveFnorm_Err(i) = sum(Fnorm_Err(i,:))/ntest;  aveFnorm_nz(i)= sum(Fnorm_nz(i,:))/ntest;
    
    aveFnorm_Indx(i) = sum(Fnorm_Indx(i,:))/ntest;  aveFnorm_time(i)=sum(Fnorm_time(i,:))/ntest;
    
    aveInf_Err(i) = sum(Inf_Err(i,:))/ntest;  aveInf_nz(i) = sum(Inf_nz(i,:))/ntest;
    
    aveInf_Indx(i) =sum(Inf_Indx(i,:))/ntest;  aveInf_time(i) =sum(Inf_time(i,:))/ntest;
    
    aveLoh_Err(i) = sum(Loh_Err(i,:))/ntest;  aveLoh_nz(i)=sum(Loh_nz(i,:))/ntest;
    
    aveLoh_Indx(i) = sum(Loh_Indx(i,:))/ntest;   aveLoh_time(i) =sum(Loh_time(i,:))/ntest;
    
end

%% **************** high noise case *****************************

haveFnorm_Err = aveFnorm_Err;  haveFnorm_NC = aveFnorm_Indx;

haveFnorm_NIC = aveFnorm_nz -aveFnorm_Indx;  haveFnorm_time = aveFnorm_time;

save('hFro_result','haveFnorm_Err','haveFnorm_NC','haveFnorm_NIC','haveFnorm_time');

haveInf_Err = aveInf_Err;  haveInf_NC = aveInf_Indx; 

haveInf_NIC = aveInf_nz - aveInf_Indx;  haveInf_time = aveInf_time;

save('hInf_result','haveInf_Err','haveInf_NC','haveInf_NIC','haveInf_time');

haveLoh_Err = aveLoh_Err; haveLoh_NC = aveLoh_Indx; 

haveLoh_NIC = aveLoh_nz - aveLoh_Indx;  haveLoh_time = aveLoh_time;

save('hLoh_result','haveLoh_Err','haveLoh_NC','haveLoh_NIC','haveLoh_time');


%% %**************** low noise case *****************************
% 
% laveFnorm_Err = aveFnorm_Err;  laveFnorm_NC = aveFnorm_Indx;
% 
% laveFnorm_NIC =aveFnorm_nz- aveFnorm_Indx; laveFnorm_time = aveFnorm_time;

% save('lFro_result','laveFnorm_Err','laveFnorm_NC','laveFnorm_NIC','laveFnorm_time');
% 
% laveInf_Err = aveInf_Err;  laveInf_NC= aveInf_Indx;
% 
% laveInf_NIC = aveInf_nz - aveInf_Indx;  laveInf_time = aveInf_time;

% save('lInf_result','laveInf_Err','laveInf_NC','laveInf_NIC','laveInf_time');
 
% laveLoh_Err = aveLoh_Err; laveLoh_NC = aveLoh_Indx;
% 
% laveLoh_NIC =aveLoh_nz - aveLoh_Indx; laveLoh_time = aveLoh_time;
% 
% save('lLoh_result','laveLoh_Err','laveLoh_NC','laveLoh_NIC','laveLoh_time');
% 
%% **************** Plot the figures *****************************

