%% **************************************************************
%  filename:plot_figure
%
%% ***************************************************************

load('hFro_result');
load('hInf_result');
load('hPoh_result');
load('lFro_result');
load('lInf_result');
load('lPoh_result');

p = 1000;

k = round(0.5*sqrt(p));    % k-sparse

sn_factor = [4   4.2   4.4    4.6    4.8    5   5.2   5.4   5.6    5.8   6.0]';

ns_list = length(sn_factor);

for i = 1:ns;
    
    ns_list(i) = round(sn_factor(i)*k*log(p))

end

%% ******************* high_noise part ****************************

subplot(2,3,1);
h=plot(ns_list,haveFnorm_Err,'rs-', ns_list,haveInf_Err,'g+:',ns_list,havePoh_Err,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel('Relative RMSE');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 1.0')
grid on
hold on;

subplot(2,3,2);
h=plot(ns_list,haveFnorm_NC,'rs-', ns_list,haveInf_NC,'g+:',n,havePoh_NC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel(' NC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 1.0')
grid on
hold on;

subplot(2,3,3);
h=plot(ns_list,haveFnorm_NIC,'rs-', ns_list,haveInf_NIC,'g+:',ns_list,havePoh_NIC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');  ylabel(' NIC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 1.0')
grid on
hold on;

%% ******************* low_noise part ****************************

subplot(2,3,4);
h=plot(ns_list,laveFnorm_Err,'rs-',ns_list,laveInf_Err1,'g+:',ns_list,lavePoh_Err,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel('Relative RMSE');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.5')
grid on
hold on;

%% err   n,laveInf_Err,'k*:'
% 
subplot(2,3,5);
h=plot(ns_list,laveFnorm_NC,'rs-', ns_list,laveInf_NC,'g+:',ns_list,lavePoh_NC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel(' NC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.5')
grid on
hold on;



subplot(2,3,6);
h=plot(ns_list,laveFnorm_NIC,'rs-',ns_list,laveInf_NIC,'g+:',ns_list,lavePoh_NIC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');  ylabel(' NIC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.5')
grid on
hold on;






