%% ***************************************************************
%  filename:gen_example
%
%% ***************************************************************
%%
%% to generate the test examples used in our paper 
%%
%% X:  n times p  covariate matrix 
%% A:  n times p  noise matrix of covariate (for additive error)
%% M:  n times p  noise matrix of covariate (for multiplicative error and missing data)
%% Z:  n times p  corrupted covariate matrix
%% Q:  unbiased estimation for (1/n)*X'*X
%% xi/n: unbiased estimation for (1/n)*X'*y 
%% y: observed data
%% b: observed data for Loh's solver
%%

function [Q,bb,Z,y] = gen_example(betastar,pars,sigma,ysigma,example_type,randstate)

randn('state',double(randstate));
rand('state',double(randstate));

n = pars.sn;

p = pars.dim;

%% ********************** additive noise **************************

if strcmp(example_type,'A0')  % covariates obeying N(0,I), additive noise A_{ij} obeying N(0,sigma^2)
    
    X = zeros(n,p);
    
    supp_betastar = find(betastar~=0);
    
    supp_c = find(betastar==0);
    
    p1 = length(supp_betastar);
    
    p2 = p-p1;
    
    X1 = randn(n,p1);
    
    X2 = 5*randn(n,p2);
    
    X(:,supp_betastar) = X1;
    
    X(:,supp_c) = X2;
    
    % ***** check whether the irrepresentable condition holds or not ******
    
    Sigma_ss = (1/n)*X1'*X1;
    
    Sigma_scs = (1/n)*X2'*X1;
    
    SS = Sigma_scs*inv(Sigma_ss);
    
    Irrcon = max(sum(abs(SS),2));
    
    min_eig = min(eig(Sigma_ss));
    %*********************************************************************
    
    Z = X + sigma*randn(n,p);
    
    Q = (Z'*Z)/n - sigma^2*eye(p);
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = Z'*y;
    
elseif strcmp(example_type,'A1')
    
    X = randn(n,p);
    
    Z = X + sigma*randn(n,p);
    
    Q = (Z'*Z)/n - sigma^2*eye(p);
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = Z'*y;
    
elseif strcmp(example_type,'A2')  % covariates obeying uniform distribution in (0,1), additive noise A_{ij} obeying N(0,sigma^2)
    
    X = rand(n,p);

    % check whether the irrepresentative condition holds or not 
    
    supp_betastar = find(betastar~=0);
     
    supp_c = find(betastar==0);
          
    X1 = X(:,supp_betastar);
    
    X2= X(:,supp_c);
    
    Sigma_ss = (1/n)*X1'*X1;
    
    Sigma_scs = (1/n)*X2'*X1;
    
    SS = Sigma_scs*inv(Sigma_ss);
    
    Irrcon = max(sum(abs(SS),2))
    
    min(eig(Sigma_ss))
    
   %**********************************************************************
   
    Z =  X + sigma*randn(n,p);
    
    Q = (Z'*Z)/n - sigma^2*eye(p);
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = Z'*y;
    
 elseif strcmp(example_type,'A3')  % additive noise A_{ij} obeying N(0,sigma^2)
    
    SigmaX = zeros(p);
    
    for i=1:p
        
        for j=i+1:p
            
            SigmaX(i,j) = 0.5^(abs(i-j));
            
        end
    end
    
    SigmaX = SigmaX + SigmaX'+ eye(p);
    
    [P,D] = mexeig(full(SigmaX));     % X = P*diag(D)*P'
    
    C = P*sqrt(D);
    
    W = randn(p,n);             % W obeying N(0,I)
    
    tempX = C*W;                % X obeying N(0,CC^T)
    
    X = tempX';
    
    Z =  X + sigma*randn(n,p);   % A=sigma*randn(n,p)  
    
    Q = (1/n)*(Z'*Z) - sigma^2*eye(p);
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = Z'*y;
    
elseif strcmp(example_type,'A4')  % X obeying N(0,I) and A_{ij} obeying Laplace(0,sigma^2)
    
    X = randn(n,p);
    
    scale_sigma = sigma/sqrt(2);
    
    U = rand(n,p)-0.5;
    
    A = 0 - scale_sigma*sign(U).*log(1-2*abs(U));
    
    Z = X + A;
    
    Q = Z'*Z/n - sigma^2*eye(p);

    y = X*betastar + ysigma*randn(n,1);
    
    xi = Z'*y;
    
elseif strcmp(example_type,'A5')  % X obeying N(0,I) and A_{ij} obeying the uniform distribution in (0,1)
    
    X = randn(n,p);
    
    A = rand(n,p);
    
    Z = X + A;
    
    Q = (Z'*Z)/n - 1/12*eye(p);
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = Z'*y;
    
    %% ************** the following for multiplicative  data **************
    %% ********************** multiplicative data ********************
    
elseif strcmp(example_type,'M1')  % X obeying N(0,I) and log(M_{ij}) obeying N(0,sig^2I)
    
    X = randn(n,p);
                 
    M = exp(sigma*randn(n,p));
    
    sig_const1 = exp(sigma^2);
    
    mu_M = exp(sigma^2/2);   % the mean of M_{ij}
    
    Z = X.*M;
    
    Sigma_w = (n*sig_const1)*(sig_const1-1)*eye(p)+(n*mu_M^2)*ones(p);
    
    Q = (Z'*Z)./Sigma_w;
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = (Z'*y)/mu_M;  
    
elseif strcmp(example_type,'M2')  % X_{ij} obeying Laplace(0,1^2) and log(M_{ij}) obeying N(0,sig^2I)
    
    U = rand(n,p)-0.5;
    
    X = 0 - (1/sqrt(2))*sign(U).*log(1-2*abs(U));
        
    M = exp(sigma*randn(n,p));
    
    sig_const1 = exp(sigma^2);
    
    mu_M = exp(sigma^2/2);   % the mean of M_{ij}
    
    Z = X.*M;
    
    Sigma_w = (n*sig_const1)*(sig_const1-1)*eye(p)+(n*mu_M^2)*ones(p);
    
    Q = (Z'*Z)./Sigma_w;
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = Z'*y/mu_M ;
    
elseif strcmp(example_type,'M3')
    
    SigmaX = zeros(p,p);
    
    for i=1:p
        
        for j=i+1:p
            
            SigmaX(i,j) = 0.5^(abs(i-j));
            
        end
    end
    
    SigmaX = SigmaX + SigmaX'+ eye(p);
    
    [P,D] = mexeig(full(SigmaX));     % X = P*diag(D)*P'
    
    C = P*sqrt(D);
    
    W = randn(p,n);       % W obeying N(0,I)
    
    X = C*W;              % X obeying N(0,CC^T)
    
    X = X';
    
    M = exp(sigma*randn(n,p));
    
    sig_const1 = exp(sigma^2);
    
    mu_M = exp(sigma^2/2);
    
    Z = X.*M;
    
    Sigma_w = (n*sig_const1)*(sig_const1-1)*eye(p)+(n*mu_M^2)*ones(p);
    
    Q = (Z'*Z)./Sigma_w;
    
    y = X*betastar + ysigma*randn(n,1);
    
    xi = (Z'*y)/mu_M;
    
    %% ************** the following for missing data **************
    %% ********************* missing data ************************    
elseif strcmp(example_type,'M4') % X obeying N(0,I), M_{ij} obeying Bernoulli(0,alpha(1-alpha))
    
    prob = pars.prob;
    
    X = randn(n,p);
       
    M = ones(n*p,1);
    
    index = randperm(n*p,round(prob*n*p));
    
    M(index) = 0;
    
    M = reshape(M,n,p);
    
    Z = X.*M;
    
    tempQ = (Z'*Z)/(n*(1-prob)^2);
    
    Q = tempQ - prob*diag(diag(tempQ));       % Estimated covariance matrix
    
    y = X*betastar + ysigma*randn(n,1) ;      % Observed data
    
    xi = (Z'*y)/(1-prob);    
    
elseif strcmp(example_type,'M5')  % X obeying exp(1), exp-distribution with mu = 1 and  var = 1
    
    prob = pars.prob;
    
    X = exprnd(1,n,p);
     
    M = ones(n*p,1);
    
    index = randperm(n*p,round(prob*n*p));
    
    M(index) = 0;
    
    M = reshape(M,n,p);
    
    Z = X.*M;
    
    tempQ = (Z'*Z)/(n*(1-prob)^2);
    
    Q = tempQ - prob*diag(diag(tempQ));     % Estimated covariance matrix
    
    y = X*betastar + ysigma*randn(n,1) ;
    
    xi = (Z'*y)/(1-prob);
    
elseif strcmp(example_type,'M6')  
    
    SigmaX = zeros(p,p);
    
    for i=1:p
        
        for j=i+1:p
            
            SigmaX(i,j) = 0.5^(abs(i-j));
            
        end
    end
    
    SigmaX = SigmaX + SigmaX'+ eye(p);
    
    [P,D] = mexeig(full(SigmaX));     % X = P*diag(D)*P'
    
    C = P*sqrt(D);
    
    W = randn(p,n);       % W obeying N(0,I)
    
    X = C*W;              % X obeying N(0,CC^T)
    
    X = X';
        
    prob = pars.prob;
    
    M = ones(n*p,1);
    
    index = randperm(n*p,round(prob*n*p));
    
    M(index) = 0;
    
    M = reshape(M,n,p);
    
    Z = X.*M;
    
    tempQ = (Z'*Z)/(n*(1-prob)^2);
    
    Q = tempQ - prob*diag(diag(tempQ));       % Estimated covariance matrix
    
    y = X*betastar + ysigma*randn(n,1) ;      % Observed data
    
    xi = (Z'*y)/(1-prob);    
    
end
bb = xi/n;

