%% ***************************************************************
%%  test_Zou_time
%% ***************************************************************
%% 
%% Copyright by Shaohua Pan, 2017.12.20
%% ****************************************************************

clear;

addpath(genpath(pwd))

%% ****************** parameters for ALMSN_Fnorm ******************

pen_factor = 10;

%% ****************** parameters for ALMSN_Fnorm ******************

OPTIONS_ADMM.printyes = 0;

OPTIONS_ADMM.maxiter = 20000;

%% *******************  main loop  *********************************

Zou_time1 = size(10,1);

Zou_time2 = size(10,1);

Zou_iter1 = size(10,1);

Zou_iter2 = size(10,1);

obj1 = size(10,1);

obj2 = size(10,1);

for iter = 1:10
    
 %   Example_type = 1;
        
    randstate = iter;
    randn('state',double(randstate));
    rand('state',double(randstate));
    
    p = 100*iter
  
    k = round(0.5*sqrt(p));    % k-sparse
    
    n = round(5*k*log(p));
    
    temp_supp = randperm(p);
    
    supp_betastar = temp_supp(1:k);

    betastar = zeros(p,1);

    betastar(supp_betastar) = randn(k,1);
    
    pars.sn = n;
    
    pars.dim = p;
    
    sigma = 0.5;   %  standard variance of noise matrix 
    
    ysigma = 1;    %  standard  variance of noise of observed data
       
   %% ************* generate noisy data and parameters ******************
        
    Q = gen_example(betastar,pars,sigma,ysigma,'A1',randstate);
        
   %% ******************* ** ******************************************
    
    OPTIONS_ADMM.tol = 1.0e-3;
   
    tstart = clock;    
             
    [Xopt_Inf1,Zou_iter1(iter),obj1(iter)] = Zou_ADMM(Q,OPTIONS_ADMM,pen_factor);
    
    Zou_time1(iter) = etime(clock,tstart);   
    
    OPTIONS_ADMM.tol = 5.0e-4;
    
    tstart = clock;    
      
    [Xopt_Inf,Zou_iter2(iter),obj2(iter)] = Zou_ADMM(Q,OPTIONS_ADMM,pen_factor);

    Zou_time2(iter) = etime(clock,tstart);   
    
end

save('Zou1','Zou_time1','Zou_iter1','obj1');

save('Zou2','Zou_time2','Zou_iter2','obj2');

p = 100:100:1000;

subplot(1,2,1);
h1=plot(p,Zou_time1,'r--s',p,Zou_time2,'k*:');  
set(h1,'LineWidth',2.5) 
xlabel('(a) p ');   ylabel('Computing time(s)');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('tol=10^{-3}','tol=5\times10^{-4}');
hold on;

subplot(1,2,2);
h1=plot(p,obj1,'r--s',p,obj2,'k*:');  
set(h1,'LineWidth',2.5) 
xlabel('(b) p ');   ylabel('Objective value(s)');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('tol=10^{-3}','tol=5\times10^{-4}');
hold on;














