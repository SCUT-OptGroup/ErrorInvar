%% ***************************************************************
%%  test_Zou_examples
%% ***************************************************************
%%
%% Copyright by Shaohua Pan, 2017.12.15
%% ****************************************************************
%% A1-A2 for additive;          hsigma = 1.0; lsigma =0.5
%% M1-M2 for multiplicative;    hsigma = 0.8; lsigma = 0.5
%% M4-M5 for missing            hsigma = 0.5; lsigma = 0.3
%%

clear;

addpath(genpath(pwd))

%% **************************************************************

randstate = 1;
randn('state',double(randstate));
rand('state',double(randstate));

tiny = 1e-8;

small_tol = 1e-5;

%% ****************** to set the parameter ****************************

p = 250;

example_type = 'A3';  % A3, M3, M6

sigma = 1.0;

ysigma = 0.5;

pars.prob = sigma;

pars.dim = p;

%% ****************** to generate the true betatstar ********************

k = 3;      % k-sparse

betastar = zeros(p,1);

betastar(1) = 3;

betastar(2) = 1.5;

betastar(5) = 2;

supp_betastar = [1,2,5];

sign_supp_betastar = sign(betastar(supp_betastar));

betastarnorm = norm(betastar);

%% ****************** parameters for ADMM_tau ********************

OPTIONS_ADMM.tol = 1.0e-4;

OPTIONS_ADMM.printyes = 0;

OPTIONS_ADMM.maxiter = 2000;

%% ********************  GEP-MSCRA ********************************

OPTIONS_MSCRA.phi_flag = 2;

OPTIONS_MSCRA.printyes = 0;

OPTIONS_MSCRA.tol = 1.0e-1;

%% **************** make 5-fold corrected CV *********************
% 
 pars.sn = 100;
 
alpha = [ 0.06   0.08    0.11    0.14    0.16    0.18   0.20    0.22    0.24    0.26    0.29    0.32]';


[~,~,Z_CV,y_CV] = gen_example(betastar,pars,sigma,ysigma,example_type,randstate);


[alpha_Fro,alpha_Inf] = CV_alpha(betastar,Z_CV,y_CV,pars,OPTIONS_MSCRA,OPTIONS_ADMM,alpha,sigma,example_type);

%**********************************************************************

ntest = 100;        % the number of test problems

Fnorm_Err = size(ntest,1);  Fnorm_nz = size(ntest,1);

Fnorm_Indx = size(ntest,1);  Fnorm_time = size(ntest,1);

Inf_Err = size(ntest,1);  Inf_nz = size(ntest,1);

Inf_Indx = size(ntest,1);  Inf_time = size(ntest,1);

Loh_Err = size(ntest,1);  Loh_nz = size(ntest,1);

Loh_Indx = size(ntest,1);  Loh_time = size(ntest,1);

%% *******************  main loop  *********************************

n = 100;

for t = 1:ntest
    
    randstate = t;
    randn('state',double(randstate));
    rand('state',double(randstate));
    
    %% ************* generate noisy data and parameters ******************
    
    [Q,bb] = gen_example(betastar,pars,sigma,ysigma,example_type,randstate);
    
    %% ******************* Fnorm *************************************
    
    x_start = zeros(p,1);
    
    tstart = clock;
    
    [Z_Fro,y_Fro] = SRproj_PSD(Q,small_tol,bb,n);
    
    OPTIONS_MSCRA.normb = norm(y_Fro);
    
    OPTIONS_MSCRA.maxiter = 4;
    
    lambda = max(0.01,(alpha_Fro/n)*max(abs(Z_Fro'*y_Fro)));
    
    [xopt_fro,nznorm_fro] = MSCRA_Unconstr(x_start,Z_Fro,y_Fro,pars,OPTIONS_MSCRA,lambda,betastar);
    
    Fnorm_time(t) = etime(clock,tstart);
    
    Fnorm_nz(t) = nznorm_fro;
    
    Fnorm_Err(t) = norm(xopt_fro-betastar)/betastarnorm;
    
    sign_supp_xoptfro = sign(xopt_fro(supp_betastar));
    
    Fnorm_Indx(t) = length(find(abs(sign_supp_xoptfro-sign_supp_betastar)<=tiny));
    
    %% ********************* Inf_norm *******************************
    
    pen_factor = 1;
    
    x_start = zeros(p,1);
    
    tstart = clock;
    
    [Z_Inf,y_Inf] = Zou_ADMM_tau(Q,OPTIONS_ADMM,pen_factor,bb,n);
    
    OPTIONS_MSCRA.normb = norm(y_Inf);
    
    lambda = max(0.01,(alpha_Inf/n)*max(abs(Z_Inf'*y_Inf)));
    
    OPTIONS_MSCRA.maxiter = 1;
    
    [xopt_inf,nznorm_inf] = MSCRA_Unconstr(x_start,Z_Inf,y_Inf,pars,OPTIONS_MSCRA,lambda,betastar);
    
    Inf_time(t) = etime(clock,tstart);
    
    Inf_Err(t)= norm(xopt_inf-betastar)/betastarnorm;
    
    Inf_nz(t) = nznorm_inf;
    
    sign_supp_xoptinf = sign(xopt_inf(supp_betastar));
    
    Inf_Indx(t) = length(find(abs(sign_supp_xoptinf -sign_supp_betastar)<=tiny));
    
    
    %% ********************* Loh's method ***************************
    
        R1 = sum(abs(betastar));
    
        MAXITS = 5000;       % maximum number of iterations
    
        stepsize = .05;      % stepsize
    
        tstart = clock;
    
        [betanew, its1] = doProjGrad(Q,bb,MAXITS,stepsize,R1);
    
        Loh_time(t)= etime(clock,tstart);
    
        Loh_Err(t) = norm(betanew-betastar)/betastarnorm;
    
        abs_betanew = abs(betanew);
    
        Loh_nz(t) = length(find(abs(betanew)>1.0e-8));
    
        sign_supp_betanew = sign(betanew(supp_betastar));
    
        Loh_Indx(t) =length(find(abs(sign_supp_betanew-sign_supp_betastar)<=tiny));
    
%     R = sum(abs(betastar));
%     
%     lambda = 0.05*sqrt(log(p)/n);
%     
%     MAXITS = 3000;       % maximum number of iterations
%     
%     stepsize = .05;      % stepsize
%     
%     tstart = clock;
%     
%     [betanew, its1] = doCompGrad(Q, bb, MAXITS, stepsize, R, lambda);
%     
%     Loh_time(t)= etime(clock,tstart);
%     
%     sign_supp_betanew = sign(betanew(supp_betastar));
%     
%     Loh_Err(t) = norm(betanew-betastar)/betastarnorm;
%     
%     Loh_nz(t)= length(find(abs(betanew)>1.0e-8));
%     
%     Loh_Indx(t) = length(find(abs(sign_supp_betanew-sign_supp_betastar)<=tiny));
    
end

aveFnorm_Err = sum(Fnorm_Err)/ntest;  aveFnorm_NC = sum(Fnorm_Indx)/ntest;

aveFnorm_NIC = sum(Fnorm_nz)/ntest - aveFnorm_NC;

aveInf_Err = sum(Inf_Err)/ntest;  aveInf_NC =sum(Inf_Indx)/ntest;

aveInf_NIC = sum(Inf_nz)/ntest - aveInf_NC; 

aveLoh_Err = sum(Loh_Err)/ntest;  aveLoh_NC = sum(Loh_Indx)/ntest;

aveLoh_NIC = sum(Loh_nz)/ntest -aveLoh_NC;
