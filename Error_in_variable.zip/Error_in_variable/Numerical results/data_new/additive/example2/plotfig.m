load('hFro_result');
load('hInf_result');
load('hLoh_result');
load('lFro_result');
load('lInf_result');
load('lLoh_result');

p = 1000

k = round(0.5*sqrt(p))    % k-sparse

nval = [4   4.2   4.4    4.6    4.8    5   5.2   5.4   5.6    5.8   6.0]';

ns = length(nval);

for i = 1:ns;
    
    n(i) = round(nval(i)*k*log(p))

end

%% ***************************************************************

subplot(2,3,1);
h=plot(n,laveFnorm_Err,'rs-', n,laveInf_Err,'g+:',n,laveLoh_Err,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel('Relative RMSE');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.5')
grid on
hold on;


%% err   n,laveInf_Err,'k*:'
% 
subplot(2,3,2);
h=plot(n,laveFnorm_NC,'rs-', n,laveInf_NC,'g+:',n,laveLoh_NC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel(' NC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.5')
grid on
hold on;



subplot(2,3,3);
h=plot(n,(laveFnorm_NIC),'rs-', n,(laveInf_NIC),'g+:',n,(laveLoh_NIC),'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');  ylabel(' NIC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.5')
grid on
hold on;


subplot(2,3,4);
h=plot(n,haveFnorm_Err,'rs-', n,haveInf_Err,'g+:',n,haveLoh_Err,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel('Relative RMSE');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 1.0')
grid on
hold on;
% 
% 
subplot(2,3,5);
h=plot(n,haveFnorm_NC,'rs-', n,haveInf_NC,'g+:',n,haveLoh_NC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel(' NC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 1.0')
grid on
hold on;

subplot(2,3,6);
h=plot(n,(haveFnorm_NIC),'rs-', n,(haveInf_NIC),'g+:',n,(haveLoh_NIC),'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');  ylabel(' NIC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 1.0')
grid on
hold on;

% 
% subplot(1,2,1);
% h=plot(n,laveFnorm_time,'rs-', n,laveInf_time1,'g+:',n,lavePoh_time,'b*-.');
% set(h,'LineWidth',1.5) 
% xlabel('n');   ylabel('Computing time (log s)');
% set(get(gca,'XLabel'),'FontSize',14);
% set(get(gca,'YLabel'),'FontSize',14);
% legend('CaZnRLS','CoCoLasso','NCL');
% title('\tau = 0.5')
% grid on
% hold on;
% 
% subplot(1,2,2);
% h=plot(n,haveFnorm_time,'rs-', n,haveInf_time1,'g+:',n,havePoh_time,'b*-.');
% set(h,'LineWidth',1.5) 
% xlabel('n');   ylabel('Computing time (log s)');
% set(get(gca,'XLabel'),'FontSize',14);
% set(get(gca,'YLabel'),'FontSize',14);
% legend('CaZnRLS','CoCoLasso','NCL');
% title('\tau = 1.0')








