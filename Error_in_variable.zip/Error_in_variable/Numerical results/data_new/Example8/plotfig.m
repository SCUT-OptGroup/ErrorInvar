load('hFro_result');
load('hInf_result');
load('hLoh_result');

p = 250;

k = round(0.5*sqrt(p))    % k-sparse

nval = [4   4.2   4.4    4.6    4.8    5   5.2   5.4   5.6    5.8   6.0]';

ns = length(nval);

for i = 1:ns;
    
    n(i) = round(nval(i)*k*log(p));

end
haveFnorm_Err
asdf
(haveInf_Err - haveFnorm_Err)./haveInf_Err

%% ***************************************************************


%% err   n,laveInf_Err,'k*:'
% 
subplot(1,3,1);
h=plot(n,haveFnorm_Err,'rs-', n,haveInf_Err,'g+:',n,haveLoh_Err,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel(' NC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.75')
grid on
hold on;

subplot(1,3,2);
h=plot(n,haveFnorm_NC,'rs-', n,haveInf_NC,'g+:',n,haveLoh_NC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');   ylabel(' NC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.75')
grid on
hold on;



subplot(1,3,3);
h=plot(n,haveFnorm_NIC,'rs-', n,haveInf_NIC,'g+:',n,haveLoh_NIC,'b*-.');
set(h,'LineWidth',1.5) 
xlabel('n');  ylabel(' NIC');
set(get(gca,'XLabel'),'FontSize',14);
set(get(gca,'YLabel'),'FontSize',14);
legend('CaZnRLS','CoCoLasso','NCL');
title('\tau = 0.5')
grid on
hold on;







