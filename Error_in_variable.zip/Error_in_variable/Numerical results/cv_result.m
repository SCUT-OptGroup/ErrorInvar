%% A1 P=500 ---example 1
% hsigma = 1;     ysigma = 0.5��    nu_Fro = 0.26(*),   nu_Inf = 0.16(*)��   
% hsigma = 1;     ysigma = 1��      nu_Fro = 0.26(*),   nu_Inf = 0.16(*)��



%% A1 P=1000 ---example 2
% hsigma = 1;     ysigma = 0.5��    nu_Fro = 0.18(*),   nu_Inf = 0.16(*)  ��     
% hsigma = 0.5;   ysigma = 0.5��    nu_Fro = 0.08(*),   nu_Inf = 0.06(*)  ��

%% A2 P=1000 ---example 3     
% hsigma = 0.5;   ysigma = 0.5��    nu_Fro = 0.06(*),   nu_Inf = 0.06(*)  ��


%% M1 P=1000 -- example 4  
% hsigma = 0.8;   ysigma = 0.5��    nu_Fro = 0.24 (*),  nu_Inf = 0.18(*) ��
% lsigma = 0.5;   ysigma = 0.5��    nu_Fro = 0.11 (*),  nu_Inf = 0.08 (*)

%% M2 P=1000 -- example 5  
% lsigma = 0.5;   ysigma = 0.5��    nu_Fro = 0.08 (*),  nu_Inf = 0.08;(*)


%% M4---example 6  
% hsigma = 0.5;   ysigma = 0.5��    nu_Fro = 0.24(*)��  nu_Inf = 0.18 (*) ��
% lsigma = 0.3;   ysigma = 0.5��    nu_Fro = 0.14(*)��  nu_Inf = 0.11��*����

%% M5---example 7   
% lsigma = 0.3;   ysigma = 0.5;    nu_Fro = 0.06(*)��   nu_Inf = 0.06(*) �� 
%%
%%


%% ************************ Zou's example ***************************
%% A3, sigma=1.0, ysigma=0.5, alpha_Fro=0.32, alpha_inf = 0.32


%% M3, sigma=0.8, ysigma=0.5, alpha_Fro=0.32, alpha_inf = 0.32


%% M6, sigma=0.5, ysigma=0.5, alpha_Fro=0.29, alpha_inf = 0.32



%% ************************ Example 8 ***************************
%% A1, sigma=0.75, ysigma=0.5, alpha_Fro=0.11, alpha_inf = 0.11

